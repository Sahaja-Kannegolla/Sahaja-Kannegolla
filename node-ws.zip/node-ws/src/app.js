var express = require('express');
var app = express();

var bodyParser = require('body-parser');
app.use(bodyParser.json());

var cors = require('cors');
app.use(cors());

const pool = require('./connector');



app.post('/login', function (req, res) {
    pool.getConnection(function (err, connection) {
        console.log(req.body);
        if (err) {
            res.status(400)
            res.send({
                errorMessage: err.message
            })
            console.log(err.message);
            return;
        }
        if (req.body.username && req.body.password) {
            connection.query('select * from employee_data where employeeId = "' + req.body.username + '"', function (err, result) {
                connection.release();
                if (err) throw err;
                if (result.length === 0) {
                    res.status(400)
                    res.send({
                        errorMessage: 'Invalid Employee Id.'
                    })
                    return
                }
                if (req.body.password !== 'Admin123') {
                    res.status(400)
                    res.send({
                        errorMessage: 'Invalid Password.'
                    })
                    return
                }
                const upcoming_batches_query = `SELECT * FROM upcoming_batches AS UBT INNER JOIN 
                allocator AS ALT ON UBT.streamId = ALT.streamId WHERE employeeId ="${req.body.username}"`
                connection.query(upcoming_batches_query, (allocatorErr, allocatorResult) => {
                    if (allocatorErr) throw allocatorErr;
                    let responseData = result[0] //[{}]
                    responseData['upcomingBatches'] = allocatorResult
                    res.status(200)
                    res.json(responseData);
                    console.log('response', responseData);
                    return
                })
            });
        } else {
            res.status(400)
            res.send({
                errorMessage: 'Employee Id or Password cannot be empty.'
            })
        }
    });

});

app.post('/streamData', function (req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            console.log(err.message);
            return;
        }
        if (req.body.streamId) {
            connection.query(`
            SELECT * FROM (
                SELECT SD.streamId, SD.streamName, SD.courseId, SD.courseName,
                SD.startDate, SD.endDate, SD.duration, SD.courseStatus,
                GROUP_CONCAT(EC.employeeId) educatorsId, GROUP_CONCAT(EC.employeeName) educatorsName,
                GROUP_CONCAT(EC.noOfTimesAsEducator) educatorsExperience,
                GROUP_CONCAT(EF.educatorFeedback) educatorsFeedback
                FROM stream_data AS SD LEFT JOIN
                educator_course AS EC ON SD.courseId = EC.courseId LEFT JOIN
                educator_feedback AS EF ON EC.employeeId = EF.employeeId AND EC.courseId = EF.courseId
                WHERE streamId='${req.body.streamId}'
                GROUP BY SD.courseId) educatorQuery LEFT JOIN 
                (
                SELECT SD2.courseId TAcourseID, GROUP_CONCAT(TC.employeeId) TAsId, GROUP_CONCAT(TC.employeeName) TAsName,
                GROUP_CONCAT(TC.noOfTimesAsTA) TAsExperience,
                GROUP_CONCAT(TF.taFeedback) TAsFeedback
                FROM stream_data AS SD2 LEFT JOIN
                ta_course AS TC ON SD2.courseId = TC.courseId LEFT JOIN
                ta_feedback AS TF ON TC.employeeId = TF.employeeId AND TC.courseId = TF.courseId
                WHERE streamId='${req.body.streamId}'
                GROUP BY SD2.courseId) tasQuery
                ON educatorQuery.courseId = tasQuery.TAcourseID
            `, function (err, result) {
                connection.release();
                if (err) throw err;
                if (result.length === 0) {
                    res.status(400)
                    res.send({
                        errorMessage: 'Invalid Stream Id.'
                    })
                    return
                }
                if (!result) {
                    res.status(400)
                    res.send({
                        errorMessage: 'Could not fetch data for this Stream Id.'
                    })
                    return
                }
                let responseData = result
                for (i in result) {
                    responseData[i]['educatorsExperience'] = (result[i]['educatorsExperience'] || '').split(',')
                    responseData[i]['educatorsId'] = (result[i]['educatorsId'] || '').split(',')
                    responseData[i]['educatorsName'] = (result[i]['educatorsName'] || '').split(',')
                    responseData[i]['educatorsFeedback'] = (result[i]['educatorsFeedback'] || '').split(',')

                    responseData[i]['TAsExperience'] = (result[i]['TAsExperience'] || '').split(',')
                    responseData[i]['TAsId'] = (result[i]['TAsId'] || '').split(',')
                    responseData[i]['TAsName'] = (result[i]['TAsName'] || '').split(',')
                    responseData[i]['TAsFeedback'] = (result[i]['TAsFeedback'] || '').split(',')
                }
                res.status(200)
                res.json({
                    streamData: responseData
                });
                return
            });
        } else {
            res.status(400)
            res.send({
                errorMessage: 'Stream Id cannot be empty.'
            })
        }
    });

});



var errorLogger = function (err, req, res, next) {
    if (err) {
        if (err.status) {
            res.status(err.status)
        } else {
            res.status(500);
        }
        res.json({ errorMessage: err.message })
    }
    next();
}

app.use(errorLogger);
app.listen(4000, function () {
    console.log('App listening on port 4000!');
});