var mysql = require('mysql');

var pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'sahaja'
});


pool.on('connection', function (connection) {
  console.log("Connected");
});



module.exports = pool;