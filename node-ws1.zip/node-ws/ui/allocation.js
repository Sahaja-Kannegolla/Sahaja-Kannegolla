function checkUserLogin() {
    if (!localStorage.getItem('userData') || !JSON.parse(localStorage.getItem('userData')).role_id) {
        localStorage.clear()
        window.location.href = './login.html'
        return
    }
    if (localStorage.getItem('MapDataSuccess')) {
        updateStreamData()
    }
    console.log(JSON.parse(localStorage.getItem('userData')).role_id);
}

function updateStreamData() {
    var data = JSON.stringify({
        username: JSON.parse(localStorage.getItem('userData')).employeeId
    })

    var req = new XMLHttpRequest();
    req.open('POST', "http://localhost:4000/updateStreamData");
    req.setRequestHeader("Content-Type", "application/json");
    req.send(data);
    req.onload = () => {
        if (req.status === 200) {
            let userData = localStorage.getItem('userData')
            var streamResponse = JSON.parse(req.responseText)
            userData['upcomingBatches'] = streamResponse['upcomingBatches']
            localStorage.setItem('streamData', null)
            localStorage.setItem('userData', JSON.stringify(userData))
        } else {
            localStorage.clear()
            // window.location.href = './login.html'
            return
        }
        return true;
    }

}

function logout() {
    localStorage.clear()
    window.location.href = './login.html'
}

const getEducatorsDD = (rawData) => {
    let tempArr = []
    const convertToInt = (number) => parseInt(number || 0)
    for (index in rawData['educatorsId']) {
        rawData['educatorsId'][index] && tempArr.push({
            employeeId: rawData['educatorsId'][index],
            employeeName: rawData['educatorsName'][index],
            feedback: rawData['educatorsFeedback'][index],
            experience: rawData['educatorsExperience'][index],
            score: (0.6 * convertToInt(rawData['educatorsFeedback'][index])) + (0.4 * convertToInt(rawData['educatorsExperience'][index]))
        })
    }
    let sortedArr = tempArr.sort((a, b) => b.score - a.score)

    const getOptions = (rawArr = []) => {
        let opt = '<option disabled selected>Select Educator</option>'
        for (i in rawArr.slice(0, 3)) {
            opt += `<option>${rawArr[i]['employeeName']}</option>`
        }
        return opt
    }

    return `<div class="form-group">
    <select class="form-control" id="${rawData['courseId']}_ed">
      ${getOptions(sortedArr)}
    </select>
  </div>`
}

const getTADD = (rawData, batchSize) => {
    if (batchSize <= 50) {
        return `Not Required`
    }
    let tempArr = []
    const convertToInt = (number) => parseInt(number || 0)
    for (index in rawData['TAsId']) {
        rawData['TAsId'][index] && tempArr.push({
            employeeId: rawData['TAsId'][index],
            employeeName: rawData['TAsName'][index],
            feedback: rawData['TAsFeedback'][index],
            experience: rawData['TAsExperience'][index],
            score: (0.6 * convertToInt(rawData['TAsFeedback'][index])) + (0.4 * convertToInt(rawData['TAsExperience'][index]))
        })
    }
    let sortedArr = tempArr.sort((a, b) => b.score - a.score)

    const getOptions = (rawArr = []) => {
        let opt = '<option disabled selected>Select TA</option>'
        for (i in rawArr.slice(0, 3)) {
            opt += `<option>${rawArr[i]['employeeName']}</option>`
        }
        return opt
    }

    return `<div class="form-group">
    <select class="form-control" id="${rawData['courseId']}_td">
      ${getOptions(sortedArr)}
    </select>
  </div>`
}

function makeBatchDeailsCall(streamId, batchSize, batchId) {
    var data = JSON.stringify({
        streamId
    })

    var req = new XMLHttpRequest();
    req.open('POST', "http://localhost:4000/streamData");
    req.setRequestHeader("Content-Type", "application/json");
    req.send(data);
    req.onload = () => {
        var streamResponse = JSON.parse(req.responseText)
        if (req.status === 200) {
            localStorage.setItem('streamData', JSON.stringify(streamResponse))
            localStorage.setItem('batchId', batchId)
            localStorage.setItem('streamId', streamId)
            var allCourseData = JSON.parse(localStorage.getItem('streamData'))
            if (allCourseData) {
                let AllCourseTableBody = document.getElementById('display_all_course_data_table_body')
                AllCourseTableBody.innerHTML = ''
                let courseData = allCourseData['streamData']
                let index = 0
                for (courseElement of courseData) {
                    if (courseElement) {
                        AllCourseTableBody.innerHTML += `
                <tr id='row_data_${index}'>
                <td id='col_row_data_${index}_courseId'>${courseElement['courseId']}</td>
                <td id='col_row_data_${index}_courseName'>${courseElement['courseName']}</td>
                <td id='col_row_data_${index}_startDate'>${new Date(courseElement['startDate']).toLocaleDateString()}</td>
                <td id='col_row_data_${index}_endDate'>${new Date(courseElement['endDate']).toLocaleDateString()}</td>
                <td id='col_row_data_${index}_ed'>${getEducatorsDD(courseElement)}</td>
                <td id='col_row_data_${index}_ta'>${getTADD(courseElement, batchSize)}</td>
                </tr>
                `
                        index += 1
                    }
                }
                document.getElementById('display_all_course_data').classList.remove('d-none')
                document.getElementById('display_all_course_data').scrollIntoView();
            }
        } else if (req.status === 400) {
            alert(streamResponse.errorMessage)
            localStorage.setItem('streamData', false)
        } else {
            alert("Internal server Error")
            localStorage.setItem('streamData', false)
        }
        return true;
    }

}

function update_educator(e) {
    e.preventDefault()
    const service_call_data = {
        updatedList: [],
        streamId: localStorage.getItem('streamId'),
        batchId: localStorage.getItem('batchId')
    }
    const table_body = document.getElementById('display_all_course_data_table_body')
    const table_rows = table_body.querySelectorAll('[id^="row_data_"]')
    if (table_rows.length > 0) {
        for (i = 0; i < table_rows.length; i++) {
            let course_id = document.getElementById('col_' + table_rows[i].id + '_courseId').innerText
            let course_name = document.getElementById('col_' + table_rows[i].id + '_courseName').innerText
            let course_start_date = document.getElementById('col_' + table_rows[i].id + '_startDate').innerText
            let course_end_date = document.getElementById('col_' + table_rows[i].id + '_endDate').innerText
            let ed_value = document.getElementById(course_id + '_ed').value
            let td_value = document.getElementById(course_id + '_td') ? document.getElementById(course_id + '_td').value : true
            if (!ed_value || ed_value === 'Select Educator') {
                alert('Please select educator for course id - ' + course_id)
                return
            }
            if (!td_value || td_value === 'Select TA') {
                alert('Please select TA for course id - ' + course_id)
                return
            }
            if (ed_value === td_value) {
                alert('Course ID ' + course_id + ' cannot have same Educator and TA.')
                return
            }
            let tempObj = {
                courseId: course_id,
                courseName: course_name,
                startDate: course_start_date,
                endDate: course_end_date,
                batchId: localStorage.getItem('batchId'),
                educator: ed_value,
                TA: td_value === true ? false : td_value
            }
            service_call_data.updatedList.push(tempObj)
        }

        makeMapEducatorTAServiceCall(service_call_data)
        console.log('Service call data', service_call_data)

    } else {
        alert('No data found to Submit.')
        return
    }
}

function makeMapEducatorTAServiceCall(reqData = {}) {
    var data = JSON.stringify({
        ...reqData
    })

    var req = new XMLHttpRequest();
    req.open('POST', "http://localhost:4000/mapETAData");
    req.setRequestHeader("Content-Type", "application/json");
    req.send(data);
    req.onload = () => {
        var mapResponse = JSON.parse(req.responseText)
        if (req.status === 200) {
            alert('Mapping success')
            localStorage.setItem('MapDataSuccess', true)
            location.reload()
        } else if (req.status === 400) {

        } else {

        }
        return true;
    }

}
